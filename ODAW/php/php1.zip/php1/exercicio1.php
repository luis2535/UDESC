<?php
//exercicio1
date_default_timezone_set('America/Sao_Paulo');

$dataHoraAtual = date('d/m/Y \à\s H:i\h');

echo "Hoje é " . $dataHoraAtual;
?>
